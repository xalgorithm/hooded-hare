Omega Kickstart Theme Information
=================================

Central base theme for theme development on the Commerce Kickstart distribution,
powered by Omega.

This theme is meant to be subthemed and become a starting point for your own
theme development that is a little more friendly OOB than Omega by itself.

Omega Kickstart is a responsive base theme.
It works for desktop, tablet, and mobile sizes well,
kicking your Commerce Kickstart theme development into high gear.

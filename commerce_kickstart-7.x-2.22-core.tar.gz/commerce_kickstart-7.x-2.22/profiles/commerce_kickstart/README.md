Commerce Kickstart
==================

Commerce Kickstart is an installation profile designed to get up and running quickly with Drupal Commerce.
It duplicates a standard Drupal installation and provides additional configuration for Commerce modules and components.

While we intend for this installation profile to be the entrance point for many new users to Drupal Commerce, we will also be maintaining drush make files and eventual Features integration to make it a starting point for advanced Drupal users to quickly build out new e-commerce sites.

[![Build Status](https://travis-ci.org/commerceguys/commerce_kickstart.svg?branch=7.x-2.x)](https://travis-ci.org/commerceguys/commerce_kickstart)
